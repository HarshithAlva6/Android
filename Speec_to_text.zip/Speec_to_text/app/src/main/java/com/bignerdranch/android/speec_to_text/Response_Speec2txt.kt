package com.bignerdranch.android.speec_to_text

data class Response_Speec2txt(
//    val bucket: String,
//    val contentDisposition: String,
//    val contentEncoding: String,
//    val contentType: String,
//    val crc32c: String,
//    val downloadTokens: String,
//    val etag: String,
//    val generation: String,
//    val md5Hash: String,
//    val metageneration: String,
//    val name: String,
//    val size: String,
//    val storageClass: String,
//    val timeCreated: String,
//    val updated: String
    val Mic_text:String
)